"""
AINN Operator Console -- a local Flask app that wraps the REAL project
code (no re-implementation, no substitutions) behind a browser UI, so the
system can be OPERATED end to end instead of only replayed:

  1. Author & Seal   (question-setter / exam authority)
       write a paper -> steps 1-6 of the custody chain -> download the
       sealed package + one private key file per custody stakeholder.
  2. Exam Day        (any 3 of the 4 custody stakeholders + exam centre)
       load the sealed package + stakeholder key files -> verify the
       co-signed ledger entry -> verify the VDF time-lock -> each node's
       AND-gate (VDF ok AND boot state unchanged) -> steps 7-9: threshold
       reconstruction inside the TEE and decryption -> integrity check of
       the recovered paper against the pre-committed hash.
  3. Live Monitor    (leak-detection analyst)
       commit a paper -> feed a channel message by message (text or photos)
       -> real detector scores it live, with the evidence behind every alert.

Run from the project root:
    pip install flask
    python webapp/app.py
Then open http://127.0.0.1:5057

Everything under /api/custody/* calls straight into src/crypto/* and
src/custody/* -- the same modules src/orchestrator.py sequences. Nothing here
reimplements AES-GCM, ML-KEM, Shamir, the VDF, TPM sealing, the ledger or the
TEE boundary; this file only adds HTTP plumbing, (de)serialisation and
per-session state.

Everything under /api/detection/* uses the REAL LeakDetector
(src/detection/engine.py) with a trained GNN, autoencoder and learned-fusion
meta-model (scripts/train_live_detector.py), a content matcher built from
whatever paper is committed (src/detection/live_paper_matcher.py) and the
real ORB+RANSAC committed-page image matcher (src/detection/image_match.py).

State is kept in memory -- this is a single-user local demo tool.
"""
import base64
import copy
import io
import json
import pickle
import random
import sys
import time
import uuid
import zipfile
from pathlib import Path

from flask import Flask, jsonify, request, send_file, send_from_directory
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Crypto.PublicKey import ECC

from src.crypto.aes_gcm import generate_content_key, encrypt_paper, decrypt_paper
from src.crypto.ml_kem_wrap import generate_node_keypair, wrap_content_key, unwrap_content_key
from src.crypto.shamir import split_secret, reconstruct_secret
from src.custody.commitment_ledger import CommitmentLedger, generate_stakeholder_keypair, hash_paper
from src.custody.tpm_sim import SoftwareTPM
from src.custody.vdf import (generate_vdf_parameters, derive_vdf_input, evaluate as vdf_evaluate,
                             prove as vdf_prove, verify as vdf_verify)
from src.custody.conditional_release import check_release
from src.custody.tee_enclave import TEEEnclave
from src.detection.live_paper_matcher import LivePaperMatcher
from src.detection.photo_sim import paper_pages, camera_photo, notes_page
from src.detection.image_match import CommittedPaperImages
from src.detection.exam_corpus import load_papers
from src.detection import leak_text

app = Flask(__name__, static_folder=str(Path(__file__).parent / "static"), static_url_path="")
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024

STAKEHOLDER_IDS = ["NTA_HQ", "STATE_AUTHORITY", "INDEPENDENT_AUDIT", "CUSTODIAN"]
STAKEHOLDER_ROLES = {
    "NTA_HQ": "National exam authority headquarters",
    "STATE_AUTHORITY": "State-level education authority",
    "INDEPENDENT_AUDIT": "Independent auditor",
    "CUSTODIAN": "Physical custodian / exam-centre network",
}
THRESHOLD = 3
PCR_INDICES = [0, 1, 2]
PACKAGE_FORMAT = "ainn-sealed-package/v1"
KEYFILE_FORMAT = "ainn-stakeholder-keyfile/v1"

CUSTODY = {}     # session_id -> dict
DETECTION = {}   # session_id -> dict

_live_bundle = None


def live_bundle():
    global _live_bundle
    if _live_bundle is None:
        path = ROOT / "data" / "cache" / "live_detector.pkl"
        if not path.exists():
            raise RuntimeError("data/cache/live_detector.pkl not found -- run `python scripts/train_live_detector.py` first.")
        with open(path, "rb") as f:
            _live_bundle = pickle.load(f)
    return _live_bundle


def _hex(d: dict) -> dict:
    return {k: (v.hex() if isinstance(v, (bytes, bytearray)) else v) for k, v in d.items()}


def _unhex(d: dict, keys) -> dict:
    out = dict(d)
    for k in keys:
        out[k] = bytes.fromhex(d[k])
    return out


def _boot_profile(sid: str) -> list:
    """The measured boot chain of this stakeholder's node (same as orchestrator.StakeholderNode.boot)."""
    return [
        {"pcr": 0, "measurement": f"firmware-hash-{sid}"},
        {"pcr": 1, "measurement": f"os-kernel-hash-{sid}"},
        {"pcr": 2, "measurement": "exam-client-app-v1.0-hash"},
    ]


def _boot_tpm(sid: str, profile: list) -> SoftwareTPM:
    tpm = SoftwareTPM(device_id=sid)
    for m in profile:
        tpm.extend(int(m["pcr"]), m["measurement"].encode())
    return tpm


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/favicon.ico")
def favicon():
    return ("", 204)


# ===========================================================================
# 1. AUTHOR & SEAL -- custody steps 1-6, then hand-off artefacts
# ===========================================================================
class StakeholderNode:
    def __init__(self, sid: str):
        self.id = sid
        self.ledger_priv, self.ledger_pub = generate_stakeholder_keypair()
        self.kem_ek, self.kem_dk = generate_node_keypair()
        self.boot_profile = _boot_profile(sid)
        self.tpm = _boot_tpm(sid, self.boot_profile)
        self.wrapped = None
        self.sealed_share = None
        self.share_x = None


@app.post("/api/custody/commit")
def custody_commit():
    body = request.get_json(force=True)
    paper_text = body.get("paper_text", "")
    paper_id = (body.get("paper_id") or "PAPER-1").strip()
    window_start_label = body.get("window_start_label") or "2026-09-20T09:00:00Z"
    center_id = (body.get("center_id") or "CTR-0001").strip()
    vdf_bits = max(10, min(int(body.get("vdf_bits", 18)), 22))

    paper = paper_text.encode("utf-8")
    if not paper.strip():
        return jsonify({"error": "The paper is empty -- write at least one question first."}), 400

    log = []
    t_all = time.time()

    def step(n, title, detail, ms):
        log.append({"n": n, "title": title, "detail": detail, "ms": round(ms, 1)})

    t = time.time()
    paper_hash = hash_paper(paper)
    step(1, "Air-gapped authoring", f"{len(paper)} bytes finalised offline; SHA-256 {paper_hash[:16]}...", (time.time() - t) * 1000)

    t = time.time()
    K = generate_content_key()
    sealed_paper = encrypt_paper(paper, K, paper_id=paper_id, window_start=window_start_label, center_id=center_id)
    step(2, "AES-256-GCM encryption",
         f"random 256-bit content key K; {len(sealed_paper['ciphertext'])}-byte ciphertext + 128-bit tag, "
         f"bound to (paper_id, window_start, center_id) as authenticated data", (time.time() - t) * 1000)

    t = time.time()
    nodes = {sid: StakeholderNode(sid) for sid in STAKEHOLDER_IDS}
    ledger = CommitmentLedger({sid: n.ledger_pub for sid, n in nodes.items()})
    entry = ledger.append(
        data={"paper_id": paper_id, "paper_hash": paper_hash, "window_start": window_start_label, "center_id": center_id},
        cosigners={sid: n.ledger_priv for sid, n in nodes.items()},
    )
    step(3, "Commit to ledger",
         f"entry #{entry['index']} hash {entry['entry_hash'][:16]}..., Ed25519-co-signed by all {len(nodes)} stakeholders",
         (time.time() - t) * 1000)

    t = time.time()
    shares = split_secret(K, threshold=THRESHOLD, total_shares=len(nodes))
    for (share_x, share_bytes), node in zip(shares, nodes.values()):
        node.share_x = share_x
        node.wrapped = wrap_content_key(share_bytes, node.kem_ek)
    step(4, "Split and wrap the key",
         f"Shamir {THRESHOLD}-of-{len(nodes)} over GF(2^8); each share encapsulated to its own node with ML-KEM-768",
         (time.time() - t) * 1000)

    t = time.time()
    for node in nodes.values():
        raw_share = unwrap_content_key(node.wrapped, node.kem_dk)
        node.sealed_share = node.tpm.seal(raw_share, pcr_indices=PCR_INDICES)
    del K, shares
    step(5, "Seal to stakeholder nodes",
         "each node decapsulates its own share and seals it to its measured boot state (PCR 0-2); K is discarded",
         (time.time() - t) * 1000)

    t = time.time()
    N = generate_vdf_parameters(modulus_bits=1024)["N"]
    T = 2 ** vdf_bits
    x = derive_vdf_input(f"ledger_entry:{entry['entry_hash']}".encode(), N)
    y = vdf_evaluate(x, T, N)
    proof = vdf_prove(x, y, T, N)
    step(6, "VDF time-lock",
         f"T = 2^{vdf_bits} = {T:,} sequential squarings mod a 1024-bit RSA modulus, input anchored to the ledger entry; "
         f"Pietrzak proof with {len(proof)} elements", (time.time() - t) * 1000)

    session_id = str(uuid.uuid4())
    CUSTODY[session_id] = {
        "paper_id": paper_id, "center_id": center_id, "window_start_label": window_start_label,
        "sealed_paper": sealed_paper, "nodes": nodes, "ledger": ledger, "entry": entry,
        "N": N, "T": T, "x": x, "y": y, "proof": proof,
    }
    return jsonify({
        "session_id": session_id, "log": log, "paper_id": paper_id, "paper_hash": paper_hash,
        "entry_hash": entry["entry_hash"], "stakeholders": [{"id": s, "role": STAKEHOLDER_ROLES[s]} for s in STAKEHOLDER_IDS],
        "threshold": THRESHOLD, "total_ms": round((time.time() - t_all) * 1000),
        "ciphertext_preview": sealed_paper["ciphertext"][:48].hex(),
    })


def _package_dict(s: dict) -> dict:
    sp, e = s["sealed_paper"], s["entry"]
    return {
        "format": PACKAGE_FORMAT,
        "paper_id": s["paper_id"], "center_id": s["center_id"], "window_start": s["window_start_label"],
        "threshold": THRESHOLD, "stakeholders": STAKEHOLDER_IDS,
        "ciphertext": {"ciphertext": sp["ciphertext"].hex(), "nonce": sp["nonce"].hex(), "tag": sp["tag"].hex()},
        "ledger_entry": {"index": e["index"], "timestamp": e["timestamp"], "data": e["data"],
                          "prev_hash": e["prev_hash"], "entry_hash": e["entry_hash"], "signatures": e["signatures"]},
        "ledger_public_keys": {sid: n.ledger_pub.export_key(format="PEM") for sid, n in s["nodes"].items()},
        "wrapped_shares_distribution_record": {sid: _hex(n.wrapped) for sid, n in s["nodes"].items()},
        "vdf": {"N": str(s["N"]), "T": s["T"], "x": str(s["x"]), "y": str(s["y"]), "proof": [str(v) for v in s["proof"]]},
        "note": f"This package cannot be opened on its own. Reconstructing the content key needs the key files of "
                f"at least {THRESHOLD} of the {len(STAKEHOLDER_IDS)} stakeholders, each of whose shares only unseals "
                f"on that stakeholder's untampered node, and only with a valid VDF proof.",
    }


def _keyfile_dict(s: dict, sid: str) -> dict:
    n = s["nodes"][sid]
    return {
        "format": KEYFILE_FORMAT,
        "stakeholder_id": sid, "role": STAKEHOLDER_ROLES[sid],
        "paper_id": s["paper_id"], "ledger_entry_hash": s["entry"]["entry_hash"],
        "share_x": n.share_x,
        "tpm_sealed_share": _hex(n.sealed_share),
        "node_boot_profile": n.boot_profile,
        "note": "PRIVATE -- give only to this stakeholder. The share inside is sealed to this node's measured boot "
                "state. (Simulation caveat: a hardware TPM would bind the seal to the physical chip; this software "
                "TPM reproduces the boot-state check by replaying the node's measured boot chain.)",
    }


def _json_download(obj, name):
    return send_file(io.BytesIO(json.dumps(obj, indent=2).encode()), mimetype="application/json",
                     as_attachment=True, download_name=name)


@app.get("/api/custody/package/<session_id>")
def custody_package(session_id):
    s = CUSTODY.get(session_id)
    if not s:
        return jsonify({"error": "unknown session"}), 404
    if request.args.get("inline"):
        return jsonify(_package_dict(s))
    return _json_download(_package_dict(s), f"{s['paper_id']}_sealed_package.json")


@app.get("/api/custody/keyfile/<session_id>/<sid>")
def custody_keyfile(session_id, sid):
    s = CUSTODY.get(session_id)
    if not s or sid not in STAKEHOLDER_IDS:
        return jsonify({"error": "unknown session or stakeholder"}), 404
    if request.args.get("inline"):
        return jsonify(_keyfile_dict(s, sid))
    return _json_download(_keyfile_dict(s, sid), f"{s['paper_id']}_{sid}_keyfile.json")


@app.get("/api/custody/bundle/<session_id>")
def custody_bundle(session_id):
    s = CUSTODY.get(session_id)
    if not s:
        return jsonify({"error": "unknown session"}), 404
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"{s['paper_id']}_sealed_package.json", json.dumps(_package_dict(s), indent=2))
        for sid in STAKEHOLDER_IDS:
            z.writestr(f"keyfiles/{s['paper_id']}_{sid}_keyfile.json", json.dumps(_keyfile_dict(s, sid), indent=2))
        z.writestr("README.txt",
                   f"AINN sealed exam paper {s['paper_id']} (centre {s['center_id']}, window {s['window_start_label']})\n\n"
                   f"{s['paper_id']}_sealed_package.json  -> can be distributed to every party.\n"
                   f"keyfiles/*_keyfile.json          -> PRIVATE, one per custody stakeholder.\n\n"
                   f"On exam day, load the package plus any {THRESHOLD} key files into the Exam Day tab "
                   f"of the AINN Operator Console.\n")
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"{s['paper_id']}_custody_handoff.zip")


# ===========================================================================
# 2. EXAM DAY -- open a sealed package with stakeholder key files (steps 7-9)
# ===========================================================================
@app.post("/api/custody/open")
def custody_open():
    body = request.get_json(force=True)
    pkg = body.get("package")
    keyfiles = body.get("keyfiles") or []
    tamper_nodes = body.get("tamper_nodes") or {}
    tamper_pkg = body.get("tamper_package") or {}
    if not pkg or pkg.get("format") != PACKAGE_FORMAT:
        return jsonify({"error": "That is not an AINN sealed package (format field missing or wrong)."}), 400
    pkg = copy.deepcopy(pkg)
    checks = []

    # -- simulated in-transit tampering, applied to the package BEFORE any check --
    if tamper_pkg.get("ciphertext"):
        c = bytearray.fromhex(pkg["ciphertext"]["ciphertext"])
        c[len(c) // 2] ^= 0x01
        pkg["ciphertext"]["ciphertext"] = c.hex()
    if tamper_pkg.get("ledger"):
        pkg["ledger_entry"]["data"]["window_start"] = "2020-01-01T00:00:00Z"  # try to back-date the exam window

    # -- check A: the co-signed ledger entry --
    try:
        pubs = {sid: ECC.import_key(pem) for sid, pem in pkg["ledger_public_keys"].items()}
        ledger = CommitmentLedger(pubs)
        ledger.entries = [pkg["ledger_entry"]]
        ledger_ok, ledger_problem = ledger.verify_chain(required_signers=set(pkg["stakeholders"]))
    except Exception as e:
        ledger_ok, ledger_problem = False, f"could not verify: {e}"
    checks.append({"name": "Ledger entry: hash + 4 Ed25519 co-signatures", "ok": ledger_ok,
                   "detail": "every signature verifies and the entry hash matches its contents" if ledger_ok else ledger_problem})

    # -- check B: VDF input is bound to THIS ledger entry --
    N, T, x, y = int(pkg["vdf"]["N"]), int(pkg["vdf"]["T"]), int(pkg["vdf"]["x"]), int(pkg["vdf"]["y"])
    proof = [int(v) for v in pkg["vdf"]["proof"]]
    anchor_ok = derive_vdf_input(f"ledger_entry:{pkg['ledger_entry']['entry_hash']}".encode(), N) == x
    checks.append({"name": "VDF input anchored to this ledger entry", "ok": anchor_ok,
                   "detail": "x = H(ledger entry hash) mod N" if anchor_ok else "VDF input does not derive from this entry"})

    # -- check C: VDF proof itself (log2(T) rounds, fast side of the asymmetry) --
    t = time.time()
    vdf_ok = vdf_verify(x, y, T, N, proof)
    checks.append({"name": f"VDF proof (T = {T:,} squarings)", "ok": vdf_ok,
                   "detail": f"verified in {(time.time() - t) * 1000:.1f} ms with {len(proof)} proof elements"})

    # -- step 7: each stakeholder node's AND gate --
    nodes, released, seen = [], [], set()
    for kf in keyfiles:
        sid = kf.get("stakeholder_id", "?")
        r = {"stakeholder_id": sid, "role": STAKEHOLDER_ROLES.get(sid, ""), "released": False,
             "tampered": bool(tamper_nodes.get(sid)), "vdf_ok": vdf_ok, "tpm_ok": False, "reason": None}
        if kf.get("format") != KEYFILE_FORMAT or sid not in pkg["stakeholders"]:
            r["reason"] = "not a key file for a stakeholder of this package"
        elif sid in seen:
            r["reason"] = "duplicate -- this stakeholder's key file was already loaded"
        elif kf.get("ledger_entry_hash") != pkg["ledger_entry"]["entry_hash"]:
            r["reason"] = "key file belongs to a different paper (ledger entry hash mismatch)"
        elif not ledger_ok:
            r["reason"] = "node refuses: the ledger entry failed verification"
        else:
            seen.add(sid)
            tpm = _boot_tpm(sid, kf["node_boot_profile"])
            if r["tampered"]:
                tpm.extend(1, b"MALICIOUS-modified-exam-client-binary")
            sealed = _unhex(kf["tpm_sealed_share"], ["policy_digest", "ciphertext", "nonce", "tag"])
            cr = check_release(tpm, sealed, N, x, y, T, proof)
            r.update(released=cr["released"], vdf_ok=cr["vdf_ok"], tpm_ok=cr["tpm_ok"],
                     reason=None if cr["released"] else "; ".join(filter(None, [cr["vdf_reason"], cr["tpm_reason"]])))
            if cr["released"]:
                released.append((int(kf["share_x"]), cr["share"]))
        nodes.append(r)

    # -- steps 8-9: reconstruct inside the TEE, decrypt, check against the commitment --
    sp = {"ciphertext": bytes.fromhex(pkg["ciphertext"]["ciphertext"]), "nonce": bytes.fromhex(pkg["ciphertext"]["nonce"]),
          "tag": bytes.fromhex(pkg["ciphertext"]["tag"]), "paper_id": pkg["paper_id"],
          "window_start": pkg["window_start"], "center_id": pkg["center_id"]}
    result = {"released_count": len(released), "threshold": pkg["threshold"], "opened": False,
              "plaintext": None, "hash_matches_commitment": None, "error": None}
    if not released:
        result["error"] = ("Every node refused, because the ledger entry failed verification: the package was altered "
                           "after the stakeholders co-signed it." if not ledger_ok else
                           "No stakeholder released a share, so there is nothing to reconstruct.")
    else:
        enclave = TEEEnclave(name=f"EXAM_CENTER_{pkg['center_id']}")
        try:
            with enclave:
                plaintext = enclave.run_protected(shares=released[:pkg["threshold"]],
                                                  operation=lambda k: decrypt_paper(sp, k))
            result.update(opened=True, plaintext=plaintext.decode("utf-8", errors="replace"),
                          hash_matches_commitment=hash_paper(plaintext) == pkg["ledger_entry"]["data"]["paper_hash"])
        except ValueError:
            if len(released) < pkg["threshold"]:
                result["error"] = (f"Only {len(released)} of {pkg['threshold']} shares released. The TEE tried anyway: the key "
                                   f"rebuilt from {len(released)} share(s) is wrong, and AES-GCM rejected it. Fewer than "
                                   f"{pkg['threshold']} Shamir shares carry no information about the key.")
            else:
                result["error"] = ("AES-GCM authentication failed: the ciphertext or its bound metadata was altered "
                                   "after sealing. The paper is refused, not decrypted into garbage.")
    return jsonify({"checks": checks, "nodes": nodes, "result": result})


# ===========================================================================
# 3. LIVE MONITOR -- real detector, content matcher and page-image matcher
# ===========================================================================
def _pages_for(paper_id, questions):
    qs = [{"number": q["number"], "qid": q["qid"], "stem_plain": q["stem"], "options_plain": {}} for q in questions]
    return paper_pages(paper_id, qs, header_override=paper_id)


# Public past papers in the same booklet format. Used two ways, never overlapping:
#  - IMPOSTOR_PAPERS are indexed next to the committed pages (open-set verification): a photo
#    only counts as a match if a COMMITTED page beats every one of these same-format pages.
#    Without this, a paper with a single page has no runner-up, and any photo of any exam page
#    in the same layout (same fonts, header rule, rough-work footer) looks like a match.
#  - OTHER_PAPERS feed the "photo of a different paper" button, so that test is never a photo
#    of a page the index already knows.
IMPOSTOR_PAPERS = ["JEE Adv 2016 Paper 1", "JEE Adv 2017 Paper 2", "JEE Adv 2018 Paper 1"]
OTHER_PAPERS = ["JEE Adv 2020 Paper 1", "JEE Adv 2021 Paper 2"]
_impostor_cache = None


def impostor_pages():
    global _impostor_cache
    if _impostor_cache is None:
        papers = load_papers()
        _impostor_cache = []
        for name in IMPOSTOR_PAPERS:
            _impostor_cache += paper_pages(name, papers[name])[:3]
    return _impostor_cache


class OpenSetPageIndex:
    def __init__(self, paper_id, committed_pages):
        self.n = len(committed_pages)
        self.index = CommittedPaperImages(paper_id, list(committed_pages) + impostor_pages())

    def match(self, img):
        r = self.index.match(img)
        if r["page"] is not None and r["page"] > self.n:          # closest page is NOT a committed one
            r.update(page=None, qids=[], orb_score=0.0, score=r["phash_score"],
                     rejected_as="closest page is a public same-format reference page, not the committed paper")
        return r


def _png(img, max_side=None):
    im = img.convert("RGB") if img.mode not in ("RGB", "L") else img
    if max_side:
        im = im.copy()
        im.thumbnail((max_side, max_side))
    buf = io.BytesIO()
    im.save(buf, format="PNG" if not max_side else "JPEG", quality=80)
    return buf.getvalue()


@app.get("/api/detection/demo_papers")
def detection_demo_papers():
    b = live_bundle()
    return jsonify({
        "papers": [{"paper_id": p["paper_id"], "topic": p["topic"], "n_questions": len(p["questions"]),
                    "questions": p["questions"]} for p in b["demo_papers"]],
        "evaluation": {k: v for k, v in b["evaluation"].items()},
    })


@app.post("/api/detection/commit_paper")
def detection_commit_paper():
    body = request.get_json(force=True)
    paper_id = (body.get("paper_id") or "LIVE").strip()
    questions = [q for q in (body.get("questions") or []) if (q.get("stem") or "").strip()]
    if len(questions) < 3:
        return jsonify({"error": "Enter at least 3 questions (the answer-key signal needs at least 3 to score)."}), 400
    for i, q in enumerate(questions):
        q["number"] = i + 1
        q["qid"] = f"{paper_id}#Q{q['number']}"
        q["gold"] = (q.get("gold") or "A").strip().upper()
        q["stem"] = q["stem"].strip()

    t = time.time()
    matcher = LivePaperMatcher(questions, backend="wordllama")
    pages = _pages_for(paper_id, questions)
    index = OpenSetPageIndex(paper_id, pages)
    session_id = str(uuid.uuid4())
    DETECTION[session_id] = {
        "paper_id": paper_id, "questions": questions, "matcher": matcher, "pages": pages, "index": index,
        "window_start": 1_800_000_000.0, "events": [], "next_hours_before": 240.0, "photo_n": 0,
        "rng": random.Random(7),
    }
    return jsonify({"session_id": session_id, "paper_id": paper_id, "n_questions": len(questions),
                    "pages": [{"page": i + 1, "qids": qids} for i, (_, qids) in enumerate(pages)],
                    "semantic_available": matcher.Q_sem is not None, "ms": round((time.time() - t) * 1000)})


@app.get("/api/detection/page/<session_id>/<int:page>")
def detection_page(session_id, page):
    s = DETECTION.get(session_id)
    if not s or not (1 <= page <= len(s["pages"])):
        return jsonify({"error": "unknown session or page"}), 404
    return send_file(io.BytesIO(_png(s["pages"][page - 1][0])), mimetype="image/png")


def _next_ts(s, body):
    hb = body.get("hours_before_exam")
    if hb in (None, ""):
        hb = s["next_hours_before"]
        s["next_hours_before"] = max(0.0, s["next_hours_before"] - float(body.get("step_hours", 3.0)))
    return float(hb), s["window_start"] - float(hb) * 3600.0


def _score(s, event_out):
    session_dict = {"session_id": "live", "window_start": s["window_start"], "events": s["events"]}
    det = live_bundle()["detector"]
    prob = float(det.predict_proba([session_dict])[0])
    ex = det.explain(session_dict)
    return {
        "p_leak": round(prob, 4), "threshold": round(float(det.threshold), 4), "alert": prob >= det.threshold,
        "weights": det.weights(), "signals": ex["signals"], "contributions": ex["contributions"],
        "top_messages": ex["top_messages"], "top_images": ex["top_images"],
        "event": event_out, "n_messages": len(s["events"]),
    }


@app.post("/api/detection/sample_text")
def detection_sample_text():
    """Realistic message text from the project's own leak_text.py generators -- the same ones the
    training data was built with. Leak styles render a real question of the COMMITTED paper."""
    body = request.get_json(force=True)
    s = DETECTION.get(body.get("session_id"))
    if not s:
        return jsonify({"error": "unknown session -- commit a paper first"}), 404
    kind, rng = body.get("kind", "chatter"), s["rng"]
    fill = lambda pool: leak_text.fill(rng.choice(pool), rng)
    if kind == "chatter":
        return jsonify({"text": fill(leak_text.STUDY_CHATTER), "note": "ordinary study chatter"})
    if kind == "scam":
        return jsonify({"text": fill(leak_text.SCAM_POSTS), "note": "scam post: leak language, no committed content"})
    if kind == "broker":
        return jsonify({"text": fill(leak_text.BROKER_LINES), "note": "broker coordination line, no committed content"})
    if kind == "coaching":
        return jsonify({"text": fill(leak_text.COACHING_BROADCAST), "note": "coaching-channel broadcast"})
    qs = s["questions"]
    if kind == "answer_key":
        picked = sorted(rng.sample(qs, k=min(len(qs), rng.randint(4, 8))), key=lambda q: q["number"])
        return jsonify({"text": leak_text.answer_key(picked, rng), "note": f"answer-key dump for {len(picked)} committed questions"})
    if kind not in leak_text.RENDERERS:
        return jsonify({"error": f"unknown kind {kind}"}), 400
    q = rng.choice(qs)
    qd = {"number": q["number"], "qid": q.get("source_qid") or q["qid"], "plain": q["stem"], "stem_plain": q["stem"], "gold": q["gold"]}
    text = leak_text.RENDERERS[kind](qd, rng)
    authored = kind in ("paraphrase", "hinglish") and qd["qid"] in leak_text.authored_paraphrases() \
        and (kind == "paraphrase" and "paraphrase_en" in leak_text.authored_paraphrases()[qd["qid"]]
             or kind == "hinglish" and "student_hinglish" in leak_text.authored_paraphrases()[qd["qid"]])
    how = {"verbatim": "copied verbatim", "excerpt": "partial excerpt", "ocr": "OCR'd from a phone photo, with OCR errors",
           "typed": "retyped by a student with abbreviations", "paraphrase": "paraphrased", "hinglish": "rewritten in Hinglish"}[kind]
    note = f"Q{q['number']} {how}" + (" (human-written, from data/annotations)" if authored else
                                      (" (rule-based rewrite)" if kind in ("paraphrase", "hinglish") else ""))
    return jsonify({"text": text, "note": note, "qid": q["qid"]})


@app.post("/api/detection/add_message")
def detection_add_message():
    body = request.get_json(force=True)
    s = DETECTION.get(body.get("session_id"))
    if not s:
        return jsonify({"error": "unknown session -- commit a paper first"}), 404
    text = (body.get("text") or "").strip()
    if not text:
        return jsonify({"error": "empty message"}), 400
    sender, group = body.get("sender") or "user1", body.get("group") or "group1"
    hb, ts = _next_ts(s, body)
    r = s["matcher"].score_messages([text])[0]
    real = max(r["lexical"], r["semantic"], r["answer_key"]) > 0.2   # same idea as live_demo.py's display cutoff
    s["events"].append({"timestamp": ts, "sender_id": sender, "group_id": group, "region": "r0",
                        "event_type": "text", "text": text,
                        "_ev": {"kind": "text", "lexical": r["lexical"], "semantic": r["semantic"],
                                "answer_key": r["answer_key"], "matched_qid": r["matched_qid"], "evidence": r["evidence"]}})
    s["events"].sort(key=lambda e: e["timestamp"])
    return jsonify(_score(s, {
        "kind": "text", "hours_before_exam": hb, "sender": sender, "group": group, "text": text,
        "matched_qid": r["matched_qid"] if real else None, "evidence": r["evidence"] if real else None,
        "lexical": round(r["lexical"], 3), "semantic": round(r["semantic"], 3), "answer_key": round(r["answer_key"], 3),
        "answer_key_pairs": r["answer_key_pairs"], "answer_key_matched": r["answer_key_matched"],
    }))


@app.post("/api/detection/add_photo")
def detection_add_photo():
    """Either a real uploaded photo (multipart 'photo'), or a simulated phone photo made by photo_sim.camera_photo."""
    if request.files.get("photo"):
        form = request.form
        s = DETECTION.get(form.get("session_id"))
        if not s:
            return jsonify({"error": "unknown session -- commit a paper first"}), 404
        try:
            img = Image.open(request.files["photo"].stream).convert("RGB")
        except Exception:
            return jsonify({"error": "could not read that file as an image"}), 400
        source = f"uploaded file '{request.files['photo'].filename}'"
        body = dict(form)
    else:
        body = request.get_json(force=True)
        s = DETECTION.get(body.get("session_id"))
        if not s:
            return jsonify({"error": "unknown session -- commit a paper first"}), 404
        kind, rng = body.get("simulate", "committed_page"), s["rng"]
        strength = float(body.get("strength", 1.0))
        if kind == "committed_page":
            p = int(body.get("page") or rng.randint(1, len(s["pages"])))
            p = max(1, min(p, len(s["pages"])))
            img = camera_photo(s["pages"][p - 1][0], rng, strength=strength)
            source = f"simulated phone photo of committed page {p}"
        elif kind == "other_paper":
            name = rng.choice(OTHER_PAPERS)
            img = camera_photo(rng.choice(paper_pages(name, load_papers()[name]))[0], rng, strength=strength)
            source = f"simulated phone photo of a different paper ({name}) in the same booklet format"
        else:
            img = camera_photo(notes_page(rng), rng, strength=strength)
            source = "simulated phone photo of handwritten formula notes"

    t = time.time()
    m = s["index"].match(img)
    match_ms = (time.time() - t) * 1000
    sender, group = body.get("sender") or "user1", body.get("group") or "group1"
    hb, ts = _next_ts(s, body)
    s["photo_n"] += 1
    image_id = f"photo{s['photo_n']:03d}"
    s["events"].append({"timestamp": ts, "sender_id": sender, "group_id": group, "region": "r0",
                        "event_type": "image", "text": "", "image_id": image_id,
                        "_ev": {"kind": "image", "phash": m["phash_score"], "orb": m["orb_score"],
                                "page": m["page"], "inliers": m["inliers"], "qids": m["qids"]}})
    s["events"].sort(key=lambda e: e["timestamp"])
    thumb = base64.b64encode(_png(img, max_side=360)).decode()
    real = m["orb_score"] > 0.3
    return jsonify(_score(s, {
        "kind": "image", "hours_before_exam": hb, "sender": sender, "group": group, "image_id": image_id,
        "source": source, "thumbnail": "data:image/jpeg;base64," + thumb,
        "orb": round(m["orb_score"], 3), "phash": round(m["phash_score"], 3), "inliers": m["inliers"],
        "second_inliers": m["second_inliers"], "ncc": m["ncc"], "page": m["page"] if real else None,
        "qids": m["qids"] if real else [], "match_ms": round(match_ms), "rejected_as": m.get("rejected_as"),
        "matched_qid": (", ".join(q.split("#")[1] for q in m["qids"]) if real else None),
        "evidence": "image_orb" if real else None,
    }))


@app.post("/api/detection/reset")
def detection_reset():
    s = DETECTION.get(request.get_json(force=True).get("session_id"))
    if s:
        s["events"], s["next_hours_before"], s["photo_n"] = [], 240.0, 0
    return jsonify({"ok": True})


if __name__ == "__main__":
    print("Loading the trained live detector (data/cache/live_detector.pkl)...")
    try:
        ev = live_bundle()["evaluation"]
        print(f"  loaded. held-out F1={ev['f1']:.3f}  precision={ev['precision']:.3f}  recall={ev['recall']:.3f}")
        print(f"  learned fusion weights: {ev['weights']}")
    except Exception as e:
        print(f"  WARNING: {e}")
    print("Preparing reference pages for photo verification...")
    impostor_pages()
    url = "http://127.0.0.1:5057"
    print(f"\nAINN Operator Console -> {url}   (Ctrl+C to stop)\n")
    if "--no-browser" not in sys.argv:
        import threading
        import webbrowser
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    app.run(host="127.0.0.1", port=5057, debug=False, threaded=True)
