# AINN Operator Console

A local web app that puts a browser UI on the project's real code. It does
not reimplement or mock anything: every button calls `src/crypto/*`,
`src/custody/*` and `src/detection/*`.

## Start it

From the project folder (the one that contains `src/`):

```
pip install -r requirements.txt
python webapp/app.py
```

On Windows you can double-click `webapp\run_console.bat` instead. The browser
opens at **http://127.0.0.1:5057**. The server only listens on your own
machine.

The trained model the Live Monitor uses is already in
`data/cache/live_detector.pkl`. To retrain it yourself (about 2 minutes):
`python scripts/train_live_detector.py`.

## The three tabs

| Tab | Who it stands for | What it does |
|---|---|---|
| 1 Author & Seal | question setter / exam authority | Custody steps 1-6 on your own paper text: AES-256-GCM, ledger entry co-signed by 4 stakeholders (Ed25519), Shamir 3-of-4 split, ML-KEM-768 per share, TPM sealing per node, VDF time-lock. Outputs a sealed package plus one private key file per stakeholder (download separately or as one zip). |
| 2 Exam Day | custody stakeholders + exam centre | Load the package and any key files. Verifies the ledger signatures and the VDF proof, runs each node's AND-gate, then steps 7-9: rebuild the key inside the TEE boundary, decrypt, and check the paper's SHA-256 against the committed hash. |
| 3 Live Monitor | leak-detection analyst | Commit a paper, then feed a channel message by message or photo by photo. The trained detector scores it after every item and shows which evidence drove the score. |

## A 5-minute demo run-sheet

1. **Tab 1.** Edit the sample paper (or paste your own). Press *Seal the paper*.
   Point at the custody log: each row shows what ran and how long it took; the
   VDF row genuinely takes about 2 seconds. Show the five hand-off files.
2. Press *Continue to Exam Day with these files*.
3. **Tab 2.** Click the scenarios in order:
   - *Honest opening (3 of 4)*: all checks pass, paper opens, hash matches.
   - *One node tampered*: that node has a valid time proof but a changed boot
     state, so it refuses. This is the AND-gate. The other three still open it.
   - *Only 2 key files*: the TEE tries anyway, and AES-GCM rejects the key.
     Two Shamir shares carry no information about the key.
   - *Ciphertext altered in transit*: rejected by AES-GCM authentication.
   - *Ledger entry back-dated*: signatures no longer verify, every node refuses.
4. **Tab 3.** Press *Import the paper from Author & Seal*, set the answer key,
   then *Commit paper*. Press *Play a leak channel*: chatter stays near 0, then
   the first photo of a committed page or leaked question crosses the
   threshold, and the evidence panel names the matched question or page.
5. Press *Play a scam channel*: broker hype, fake answer keys and photos of a
   different paper, none of which carry committed content. It stays low.
6. Optional: load the held-out JEE Advanced 2023 Paper 2 (never seen in
   training) and try *Leak: paraphrased* or *Leak: Hinglish*.

## Numbers the console quotes

The Live Monitor model is `engine.LeakDetector` trained with
`scripts/train_live_detector.py` on the project's hard-mode data, with
JEE Advanced 2023 Paper 2 held out entirely. On 320 fresh sessions about that
paper: precision 0.958, recall 0.863, F1 0.908. 1.3% of normal channels ever
cross the threshold while being fed message by message. The missed leaks are
the coordination-only scenario, where the paper never appears in the
monitored channel.

## What is simulated

- The TPM and TEE are software models of the real interfaces
  (`src/custody/tpm_sim.py`, `tee_enclave.py`). A hardware TPM binds a sealed
  share to the physical chip; here the boot-state check is reproduced by
  replaying the node's measured boot chain, so a key file is only as safe as
  the file itself.
- The VDF is computed at sealing time for the demo. In deployment it runs
  over the real exam window. The RSA modulus is generated locally, not by a
  multi-party ceremony.
- Channels are typed or scripted inputs, not live social-media feeds.
- State lives in memory: restarting `app.py` clears open sessions, but
  downloaded packages and key files keep working in any later session.
