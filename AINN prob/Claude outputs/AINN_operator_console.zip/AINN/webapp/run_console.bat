@echo off
REM AINN Operator Console -- double-click to start. Opens http://127.0.0.1:5057 in your browser.
cd /d "%~dp0\.."
python -c "import flask" 2>NUL || python -m pip install flask
python webapp\app.py
pause
