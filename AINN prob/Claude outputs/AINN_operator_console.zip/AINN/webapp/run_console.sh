#!/usr/bin/env bash
# AINN Operator Console -- starts the local server and opens http://127.0.0.1:5057
cd "$(dirname "$0")/.."
python3 -c "import flask" 2>/dev/null || python3 -m pip install flask
python3 webapp/app.py
