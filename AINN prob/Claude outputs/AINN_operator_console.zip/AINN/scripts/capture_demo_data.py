"""
Runs the REAL AINN system end to end and dumps everything it genuinely
produces as one structured JSON file for the interactive demo front-end.

Nothing in the output JSON is hand-typed or fabricated -- every field is
read directly off the return values / log lines of:
  - src.orchestrator.run_custody_flow           (real 9-step custody chain)
  - src.attacks.attack_harness.run_all_scenarios (real 8-row attack matrix)
  - src.demo.live_demo (commit_paper, trained_detector, replay logic,
    reimplemented message-by-message here to CAPTURE each step instead of
    only printing it)

Run from the project root:
    python scripts/capture_demo_data.py
"""
import json
import random
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np


def jsonable(o):
    """Best-effort conversion of numpy/bytes/custom objects to JSON-safe values."""
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, bytes):
        return o.hex()
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    return o


def capture_custody_chain():
    from src.orchestrator import run_custody_flow, THRESHOLD, STAKEHOLDER_IDS

    paper = (
        b"JEE ADVANCED 2026 PAPER 1 -- PHYSICS SECTION\n"
        b"Q1. A particle of mass m moves in a circular orbit... "
        b"[full finalized exam content, air-gapped, never networked before this run]"
    )
    t0 = time.time()
    result = run_custody_flow(
        paper,
        paper_id="PHY-2026-A1",
        window_start_label="2026-09-20T09:00:00Z",
        center_id="CTR-0042",
        vdf_bits=18,
        verbose=False,
    )
    wall_time = time.time() - t0

    ledger = result["ledger"]
    ledger_entries = []
    for e in ledger.entries:
        ledger_entries.append({
            "index": e["index"],
            "data": jsonable(e["data"]),
            "signatures": list(e["signatures"].keys()) if isinstance(e["signatures"], dict) else list(e["signatures"]),
            "entry_hash": e["entry_hash"],
            "prev_hash": e.get("prev_hash"),
        })

    return {
        "paper_bytes_len": len(paper),
        "stakeholders": STAKEHOLDER_IDS,
        "threshold": THRESHOLD,
        "log": result["log"],
        "matches_original": bool(result["matches_original"]),
        "ledger_valid": bool(result["ledger_valid"]),
        "released_count": result["released_count"],
        "wall_time_seconds": round(wall_time, 3),
        "ledger_entries": ledger_entries,
    }


def capture_attack_scenarios():
    from src.attacks.attack_harness import run_all_scenarios

    t0 = time.time()
    results = run_all_scenarios(seed=99, verbose=False)
    wall_time = time.time() - t0

    out = []
    for r in results:
        out.append({
            "scenario": r.scenario,
            "mechanism": r.mechanism,
            "expected": r.expected,
            "passed": bool(r.passed),
            "detail": r.detail,
        })
    n_pass = sum(1 for r in results if r.passed)
    return {"scenarios": out, "n_pass": n_pass, "n_total": len(results), "wall_time_seconds": round(wall_time, 3)}


def capture_live_demo():
    """Re-run the exact live_demo pipeline (real paper, real trained detector,
    real replay scoring) but CAPTURE every message + score instead of just printing it."""
    from src.custody.commitment_ledger import hash_paper
    from src.detection.engine import annotate_events
    from src.detection.exam_corpus import load_papers
    from src.detection.image_pool import build_image_pool
    from src.detection.realistic_data import generate_session
    from src.demo.live_demo import commit_paper, trained_detector, _fmt_event

    paper_name = "JEE Adv 2023 Paper 1"
    seed = 3

    ledger, entry, paper_bytes = commit_paper(paper_name)
    det = trained_detector(paper_name, backend="auto", verbose=False)

    pool = build_image_pool(verbose=False)
    pool_by_id = {r["image_id"]: r for r in pool}

    rng = random.Random(seed)
    leak = generate_session("demo_leak", "full_leak", rng, pool, exam_paper=paper_name)
    scam = generate_session("demo_scam", "fake_leak_scam", random.Random(seed + 1), pool, exam_paper=paper_name)
    annotate_events([leak, scam], pool_by_id)

    committed_ids = {q["qid"] for q in load_papers()[paper_name]}

    channels = []
    for title, session, is_leak in ((f"Channel A: real leak (full_leak)", leak, True),
                                     (f"Channel B: 'genuine paper, pay Rs 5000' scam", scam, False)):
        ws = session["window_start"]
        evs = session["events"]
        prefixes = [dict(session, events=evs[: i + 1]) for i in range(len(evs))]
        probs = det.predict_proba(prefixes)

        messages = []
        alerted_at = None
        alert_payload = None
        for i, (e, p) in enumerate(zip(evs, probs)):
            hrs_before = (ws - e["timestamp"]) / 3600
            ev = e.get("_ev", {})
            matched_qid = None
            match_kind = None
            match_score = None
            if ev.get("kind") == "text":
                best = max(("lexical", ev["lexical"]), ("semantic", ev["semantic"]),
                            ("answer-key", ev["answer_key"]), key=lambda kv: kv[1])
                if best[1] > 0.3:
                    matched_qid = ev.get("matched_qid")
                    match_kind = best[0]
                    match_score = round(float(best[1]), 3)
            elif ev.get("kind") == "image" and ev.get("orb", 0) > 0.3:
                matched_qid = ",".join(ev.get("qids") or [])
                match_kind = "image-orb"
                match_score = round(float(ev["orb"]), 3)

            body = e.get("text") or ""
            if e["event_type"] == "image":
                body = f"[photo {e.get('image_id')}] {body}"

            messages.append({
                "i": i,
                "hours_before_exam": round(hrs_before, 2),
                "group": e["group_id"],
                "sender": e["sender_id"],
                "event_type": e["event_type"],
                "text": body,
                "p_leak": round(float(p), 4),
                "matched_qid": matched_qid,
                "match_kind": match_kind,
                "match_score": match_score,
            })

            if alerted_at is None and p >= det.threshold:
                alerted_at = i
                ex = det.explain(prefixes[i])
                matched = sorted({m["matched_qid"] for m in ex["top_messages"] if m["matched_qid"]} |
                                  {q for im in ex["top_images"] for q in im["qids"]})
                attribution_ranked = sorted(ex["contributions"].items(), key=lambda kv: -kv[1])
                alert_payload = {
                    "index": i,
                    "hours_before_exam": round(hrs_before, 2),
                    "p_leak": round(float(p), 4),
                    "threshold": round(float(det.threshold), 4),
                    "combined_score": ex.get("probability"),
                    "scores": jsonable(ex.get("signals")),
                    "weights": jsonable(det.weights()),
                    "attribution_ranked": jsonable(attribution_ranked),
                    "top_messages": jsonable(ex.get("top_messages"))[:5],
                    "top_images": jsonable(ex.get("top_images"))[:5],
                    "matched_qids": matched,
                    "matched_all_in_committed_paper": bool(matched) and set(matched) <= committed_ids,
                    "ledger_entry_index": entry["index"],
                    "ledger_paper_hash_prefix": entry["data"]["paper_hash"][:24],
                    "ledger_valid": bool(ledger.verify_chain()[0]),
                }

        channels.append({
            "title": title,
            "is_leak": is_leak,
            "session_id": session["session_id"],
            "n_messages": len(messages),
            "messages": messages,
            "final_p_leak": round(float(probs[-1]), 4),
            "alerted_at": alerted_at,
            "alert": alert_payload,
            "threshold": round(float(det.threshold), 4),
        })

    return {
        "paper_name": paper_name,
        "ledger_entry": {
            "index": entry["index"],
            "paper_hash": entry["data"]["paper_hash"],
            "answer_key_hash": entry["data"]["answer_key_hash"],
            "n_questions": entry["data"]["n_questions"],
            "signatures": list(entry["signatures"].keys()) if isinstance(entry["signatures"], dict) else list(entry["signatures"]),
        },
        "detector_weights": jsonable(det.weights()),
        "detector_threshold": round(float(det.threshold), 4),
        "channels": channels,
    }


def capture_headline_metrics():
    """Load already-computed, cached benchmark results from disk (no re-training) --
    these are the same numbers already reported and verified in docs/ML_REPORT.md."""
    p = ROOT / "reports" / "results" / "session_benchmark.json"
    out = {"source_file": str(p.relative_to(ROOT)) if p.exists() else None}
    if p.exists():
        data = json.loads(p.read_text())
        out["summary"] = data.get("summary")
    return out


def main():
    print("Capturing custody chain run...")
    custody = capture_custody_chain()
    print(f"  ok: matches_original={custody['matches_original']} ledger_valid={custody['ledger_valid']}")

    print("Capturing attack-resistance scenarios...")
    attacks = capture_attack_scenarios()
    print(f"  ok: {attacks['n_pass']}/{attacks['n_total']} passed")

    print("Capturing live detection replay (real trained detector, real committed paper)...")
    live = capture_live_demo()
    print(f"  ok: {len(live['channels'])} channels captured, "
          f"{sum(c['n_messages'] for c in live['channels'])} total messages")

    print("Loading cached headline benchmark metrics...")
    metrics = capture_headline_metrics()

    out = {
        "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "custody_chain": custody,
        "attack_scenarios": attacks,
        "live_detection": live,
        "headline_metrics": metrics,
    }

    out_path = ROOT / "reports" / "results" / "demo_capture.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(jsonable(out), indent=2))
    print(f"\nWrote {out_path} ({out_path.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
