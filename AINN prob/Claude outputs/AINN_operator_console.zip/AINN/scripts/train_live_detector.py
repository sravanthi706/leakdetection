"""
Trains the detector used by the Live Monitor tab of the local operator
console (webapp/app.py).

It is the project's own detector, trained the project's own way -- this
script only changes WHICH paper is held out and which backend is used:

  * sessions   src/detection/realistic_data.py  -- the "hard mode" generator:
                real JEE Advanced question text (JEEBench), the realistic
                ways questions get rewritten (leak_text.py: verbatim,
                excerpt, typed, Hinglish paraphrase, OCR noise), answer-key
                dumps, phone photos scored by the real ORB+RANSAC page
                matcher (image_pool.py), and the confusers that make the
                problem hard (past-paper discussion, coaching broadcasts,
                "pay Rs 5000" scams, quiet and buried leaks, coordination-
                only leaks).
  * evidence   engine.annotate_events -- char TF-IDF + WordLlama semantic
                matching + answer-key parsing against the committed paper.
  * model      engine.LeakDetector, unchanged: GNN + autoencoder + learned
                logistic-regression fusion of 6 signals, threshold chosen on
                validation data. NumPy backends, so the saved model loads on
                any machine with or without PyTorch.

Held-out evaluation: one real paper (JEE Adv 2023 Paper 2) is excluded from
training entirely; fresh sessions about it are generated afterwards and
scored. That paper is also what the console offers as "load a held-out
paper", so the demo runs on a paper the model has never seen.

Streaming check: the Live Monitor scores a channel from its very first
message, so this script also measures how often a NORMAL channel triggers
an alert at any point while it grows (prefix false-alarm rate), and adds
short 1-4 message prefixes to training so a lone chat message is not an
out-of-distribution input.

Run from the project root (takes several minutes):
    python scripts/train_live_detector.py
"""
import collections
import pickle
import random
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np

from src.detection.engine import LeakDetector, annotate_events
from src.detection.exam_corpus import load_papers
from src.detection.image_pool import build_image_pool
from src.detection.realistic_data import generate_hard_dataset, generate_session, LEAK_MIX, NORMAL_MIX

HELD_OUT = "JEE Adv 2023 Paper 2"


def short_prefixes(sessions, rng, frac=0.5):
    out = []
    for s in sessions:
        if rng.random() > frac or len(s["events"]) < 2:
            continue
        k = rng.randint(1, min(4, len(s["events"]) - 1))
        evs = s["events"][:k]
        out.append(dict(s, events=evs, session_id=f"{s['session_id']}@first{k}",
                        label="leak" if any(e["is_leak_event"] for e in evs) else "normal"))
    return out


def prf(y, p):
    tp = int(np.sum((p == 1) & (y == 1))); fp = int(np.sum((p == 1) & (y == 0))); fn = int(np.sum((p == 0) & (y == 1)))
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn) if tp + fn else 0.0
    return prec, rec, (2 * prec * rec / (prec + rec) if prec + rec else 0.0), tp, fp, fn


def main():
    t0 = time.time()
    print("Loading the real photo pool (cached after the first run)...", flush=True)
    pool = build_image_pool(verbose=False)
    pool_by_id = {r["image_id"]: r for r in pool}

    print(f"Generating hard-mode training sessions (every paper except {HELD_OUT})...", flush=True)
    ds = generate_hard_dataset(n_sessions=1000, seed=11, pool=pool)
    train_pool = [s for s in ds["sessions"] if s["exam_paper"] != HELD_OUT]

    print(f"Generating fresh held-out sessions about {HELD_OUT} (never used for training)...", flush=True)
    rng = random.Random(23)
    n_test, leak_frac = 320, 0.25
    scen = rng.choices(list(NORMAL_MIX), weights=list(NORMAL_MIX.values()), k=int(n_test * (1 - leak_frac)))
    scen += rng.choices(list(LEAK_MIX), weights=list(LEAK_MIX.values()), k=int(n_test * leak_frac))
    test = [generate_session(f"held{i:04d}", sc, random.Random(rng.randrange(1 << 30)), pool, exam_paper=HELD_OUT)
            for i, sc in enumerate(scen)]

    print("Annotating every message with real content-match evidence (WordLlama, TF-IDF, answer keys)...", flush=True)
    annotate_events(train_pool + test, pool_by_id)

    rng = random.Random(0)
    rng.shuffle(train_pool)
    cut = int(0.75 * len(train_pool))
    train, val = train_pool[:cut], train_pool[cut:]
    train = train + short_prefixes(train, rng)
    val = val + short_prefixes(val, rng)
    print(f"  train {len(train)} (incl. short prefixes)  val {len(val)}  held-out test {len(test)}", flush=True)

    print("Fitting LeakDetector (GNN + autoencoder + learned fusion, NumPy backends)...", flush=True)
    det = LeakDetector(gnn_backend="numpy", ae_backend="numpy", seed=0).fit(train, val)
    print(f"  learned fusion weights: {det.weights()}   threshold {det.threshold:.3f}", flush=True)

    # --- whole-session evaluation on the held-out paper ---
    y = np.array([s["label"] == "leak" for s in test], dtype=int)
    p = det.predict_proba(test)
    prec, rec, f1, tp, fp, fn = prf(y, (p >= det.threshold).astype(int))
    print(f"HELD-OUT ({HELD_OUT}, {len(test)} sessions): precision={prec:.3f} recall={rec:.3f} f1={f1:.3f}  "
          f"TP={tp} FP={fp} FN={fn}", flush=True)
    by_scen = collections.defaultdict(list)
    for s, pi in zip(test, p):
        by_scen[s["scenario"]].append(pi >= det.threshold)
    alert_rate = {k: round(float(np.mean(v)), 3) for k, v in sorted(by_scen.items())}
    print("  alert rate by scenario:", alert_rate, flush=True)

    # --- streaming evaluation: does a NORMAL channel ever alert while it grows? ---
    normals = [s for s in test if s["label"] == "normal"]
    ever, first_msg = 0, []
    for s in normals:
        prefixes = [dict(s, events=s["events"][:k]) for k in range(1, len(s["events"]) + 1)]
        pp = det.predict_proba(prefixes)
        first_msg.append(pp[0])
        ever += int(np.any(pp >= det.threshold))
    stream_fa = ever / len(normals)
    print(f"  normal channels that alert at ANY point while growing: {stream_fa:.3f}   "
          f"mean P(leak) after the first message: {np.mean(first_msg):.3f}", flush=True)

    qs = load_papers()[HELD_OUT]
    demo_paper = {"paper_id": "JEE-ADV-2023-P2", "topic": "JEE Advanced 2023, Paper 2 (held out)",
                  "questions": [{"number": i + 1, "stem": q["stem_plain"], "gold": q["gold"], "source_qid": q["qid"]}
                                for i, q in enumerate(qs)]}
    bundle = {
        "detector": det,
        "evaluation": {
            "held_out_paper": HELD_OUT, "n_train_sessions": len(train), "n_val_sessions": len(val),
            "n_test_sessions": len(test), "precision": prec, "recall": rec, "f1": f1,
            "alert_rate_by_scenario": alert_rate, "normal_channels_alerting_while_growing": stream_fa,
            "weights": det.weights(), "threshold": float(det.threshold),
        },
        "demo_papers": [demo_paper],
    }
    out = ROOT / "data" / "cache" / "live_detector.pkl"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "wb") as f:
        pickle.dump(bundle, f)
    print(f"\nWrote {out} in {(time.time() - t0) / 60:.1f} min", flush=True)


if __name__ == "__main__":
    main()
