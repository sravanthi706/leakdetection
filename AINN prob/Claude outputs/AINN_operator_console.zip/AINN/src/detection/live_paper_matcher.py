"""
LivePaperMatcher -- the same content-matching algorithm as
PaperContentMatcher (paper_matcher.py), but built directly from a list
of author-supplied questions instead of a lookup in exam_corpus.py's
fixed JEEBench set.

Why this needs to exist at all: paper_matcher.PaperContentMatcher's
constructor calls `load_papers()[paper_name]` -- it only knows about
the small set of JEEBench papers bundled with this project. The Live
Monitor tool lets someone actually AUTHOR a new paper (arbitrary
questions, typed in), so the matcher has to be buildable from that
text directly. Every algorithm underneath (char n-gram TF-IDF,
WordLlama semantic embedding, answer-key regex matching, calibration
against known-legitimate reference traffic) is reused UNCHANGED from
paper_matcher.py -- this class only replaces the __init__ that looked
the paper up by name.
"""

from src.detection.paper_matcher import (
    PaperContentMatcher, _global_char_vectorizer, _norm_answer, embed, normalise,
)


class LivePaperMatcher(PaperContentMatcher):
    def __init__(self, questions: list, backend: str = "wordllama", calibrate: bool = True, seed: int = 0):
        """
        questions: list of {"number": int, "qid": str, "stem": str, "gold": str}
        (exactly the fields PaperContentMatcher needs; no dependency on exam_corpus.py).
        """
        self.paper_name = "LIVE_AUTHORED_PAPER"
        self.backend = backend
        self.questions = questions
        self.gold = {q["number"]: {"answer": _norm_answer(q["gold"]), "qid": q["qid"]} for q in questions}
        self.vec = _global_char_vectorizer()  # same frozen background vocabulary as the rest of the project
        self._qtexts = [normalise(q["stem"]) for q in questions]
        self._qids = [q["qid"] for q in questions]
        self.Q_char = self.vec.transform(self._qtexts)
        self.Q_sem = None
        if backend:
            try:
                self.Q_sem = embed(self._qtexts, backend)
            except Exception:
                self.Q_sem = None
        self.cal = {"lexical": (0.0, 1.0), "semantic": (0.0, 1.0)}
        if calibrate:
            self._calibrate(seed)
