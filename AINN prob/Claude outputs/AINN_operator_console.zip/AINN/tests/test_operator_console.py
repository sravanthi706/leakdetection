"""
End-to-end tests for the operator console (webapp/app.py), through Flask's
test client -- the same HTTP calls the browser makes.

Custody: seal a paper, then open the sealed package with stakeholder key
files under every exam-day scenario the console offers.
Detection: only run when the trained live detector exists (it is produced
by scripts/train_live_detector.py and shipped in data/cache/).
"""
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "webapp"))

flask = pytest.importorskip("flask")
import app as console  # noqa: E402

PAPER = "Q1. First question text about mechanics.\nQ2. Second question about chemistry.\nQ3. Third question about calculus."


@pytest.fixture(scope="module")
def client():
    return console.app.test_client()


@pytest.fixture(scope="module")
def sealed(client):
    r = client.post("/api/custody/commit", json={"paper_text": PAPER, "paper_id": "TEST-P1", "center_id": "C1",
                                                   "window_start_label": "2026-10-01T09:00:00Z", "vdf_bits": 10})
    assert r.status_code == 200
    d = r.get_json()
    assert [s["n"] for s in d["log"]] == [1, 2, 3, 4, 5, 6]
    sid = d["session_id"]
    pkg = client.get(f"/api/custody/package/{sid}?inline=1").get_json()
    kfs = [client.get(f"/api/custody/keyfile/{sid}/{s}?inline=1").get_json() for s in console.STAKEHOLDER_IDS]
    return pkg, kfs


def _open(client, pkg, kfs, tamper_nodes=None, tamper_package=None):
    r = client.post("/api/custody/open", json={"package": pkg, "keyfiles": kfs, "tamper_nodes": tamper_nodes or {},
                                                "tamper_package": tamper_package or {}})
    assert r.status_code == 200
    return r.get_json()


def test_package_contains_no_key_material(sealed):
    pkg, _ = sealed
    text = str(pkg)
    assert "tpm_sealed_share" not in text and "node_boot_profile" not in text
    assert pkg["threshold"] == 3 and len(pkg["ledger_entry"]["signatures"]) == 4


def test_honest_three_of_four_opens_and_matches_commitment(client, sealed):
    pkg, kfs = sealed
    d = _open(client, pkg, kfs[:3])
    assert all(c["ok"] for c in d["checks"])
    assert d["result"]["opened"] and d["result"]["plaintext"] == PAPER
    assert d["result"]["hash_matches_commitment"] is True


def test_any_three_work(client, sealed):
    pkg, kfs = sealed
    d = _open(client, pkg, [kfs[0], kfs[2], kfs[3]])
    assert d["result"]["opened"] and d["result"]["plaintext"] == PAPER


def test_tampered_node_refuses_but_other_three_still_open(client, sealed):
    pkg, kfs = sealed
    d = _open(client, pkg, kfs, tamper_nodes={"CUSTODIAN": True})
    cust = next(n for n in d["nodes"] if n["stakeholder_id"] == "CUSTODIAN")
    assert cust["released"] is False and cust["vdf_ok"] is True and cust["tpm_ok"] is False  # the AND gate
    assert d["result"]["released_count"] == 3 and d["result"]["opened"]


def test_two_shares_cannot_open(client, sealed):
    pkg, kfs = sealed
    d = _open(client, pkg, kfs[:2])
    assert d["result"]["opened"] is False and d["result"]["plaintext"] is None


def test_ciphertext_tampering_is_rejected(client, sealed):
    pkg, kfs = sealed
    d = _open(client, pkg, kfs[:3], tamper_package={"ciphertext": True})
    assert d["result"]["opened"] is False and "AES-GCM" in d["result"]["error"]


def test_ledger_tampering_makes_every_node_refuse(client, sealed):
    pkg, kfs = sealed
    d = _open(client, pkg, kfs[:3], tamper_package={"ledger": True})
    assert d["checks"][0]["ok"] is False
    assert d["result"]["released_count"] == 0 and d["result"]["opened"] is False


def test_forged_vdf_proof_blocks_release(client, sealed):
    pkg, kfs = sealed
    forged = {**pkg, "vdf": {**pkg["vdf"], "y": str(int(pkg["vdf"]["y"]) + 1)}}
    d = _open(client, forged, kfs[:3])
    assert all(not n["released"] for n in d["nodes"]) and d["result"]["opened"] is False


def test_keyfile_from_another_paper_is_rejected(client, sealed):
    pkg, kfs = sealed
    r = client.post("/api/custody/commit", json={"paper_text": "other paper", "paper_id": "OTHER", "vdf_bits": 10}).get_json()
    foreign = client.get(f"/api/custody/keyfile/{r['session_id']}/CUSTODIAN?inline=1").get_json()
    d = _open(client, pkg, kfs[:2] + [foreign])
    assert "different paper" in next(n for n in d["nodes"] if n["stakeholder_id"] == "CUSTODIAN")["reason"]
    assert d["result"]["opened"] is False


needs_detector = pytest.mark.skipif(not (ROOT / "data" / "cache" / "live_detector.pkl").exists(),
                                    reason="trained live detector not present")


@needs_detector
def test_live_monitor_alerts_on_leak_not_on_chatter(client):
    qs = [{"stem": "A particle of mass m moves in a circular orbit of radius r under a central force. Derive its total energy.", "gold": "B"},
          {"stem": "Balance the redox reaction between potassium permanganate and oxalic acid in acidic medium.", "gold": "D"},
          {"stem": "Evaluate the definite integral of x^2 e^x from 0 to 1 using integration by parts.", "gold": "A"},
          {"stem": "A charged capacitor is connected across an identical uncharged capacitor. Find the energy lost.", "gold": "C"}]
    sid = client.post("/api/detection/commit_paper", json={"paper_id": "T", "questions": qs}).get_json()["session_id"]
    chatter = client.post("/api/detection/add_message", json={"session_id": sid, "text": "anyone have notes for chapter 5?"}).get_json()
    assert chatter["alert"] is False
    leak = client.post("/api/detection/add_message", json={"session_id": sid, "text": qs[2]["stem"] + " confirmed"}).get_json()
    assert leak["alert"] is True and leak["event"]["matched_qid"] == "T#Q3"
    client.post("/api/detection/reset", json={"session_id": sid})
    key = client.post("/api/detection/add_message", json={"session_id": sid, "text": "answers: Q1-B, Q2-D, Q3-A, Q4-C"}).get_json()
    assert key["alert"] is True and key["event"]["evidence"] == "answer_key"
