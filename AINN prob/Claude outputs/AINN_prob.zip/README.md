# AINN — Tamper-Evident, Time-Locked Exam Paper Distribution System

Working prototype. Full spec, patent strategy, and honest limitations: `docs/AINN_MASTER.md` —
read that first. Architecture diagrams: `docs/diagrams/`.

## Setup

```
pip install -r requirements.txt
```

Run everything from the project root (`AINN prob/`), as a module — not by `cd`-ing into `src/`:

```
python3 -m src.orchestrator
```

## Folder layout

```
src/
  crypto/       AES-256-GCM, ML-KEM key wrap, Shamir's Secret Sharing
  custody/      commitment ledger, simulated TPM, simulated TEE, VDF,
                conditional release (AND-gate), tamper response
  detection/    synthetic dataset, GNN, content-match, autoencoder,
                pHash image matching, fusion + alerting
  attacks/      attack-resistance harness (8 scenarios, spec section C.7)
  report/       CLI + PNG dashboard for one full system run
  orchestrator.py   wires custody chain + detection layer together —
                     the real 9-step data flow, end to end

docs/
  AINN_MASTER.md    single source of truth: project state, patent
                     strategy, full technical spec, diagram notes
  diagrams/         the 3 architecture diagrams (PNG + SVG)

reports/        dashboard PNGs land here when you run the dashboard
                (empty until you run it — nothing to commit here)
```

## Running each piece

Every module under `src/` is runnable directly and self-tests itself:

```
python3 -m src.crypto.aes_gcm
python3 -m src.crypto.shamir
python3 -m src.custody.tpm_sim
python3 -m src.custody.vdf
python3 -m src.custody.tamper_response
python3 -m src.detection.synthetic_data
python3 -m src.detection.gnn
python3 -m src.detection.fusion
python3 -m src.orchestrator            # full custody chain + detection layer
python3 -m src.attacks.attack_harness  # all 8 attack-resistance scenarios
python3 -m src.report.dashboard        # one full run -> CLI summary + PNG
```

## What's real vs. simulated

Every module is working code, not pseudo-code — but a few components are honest substitutes for
things this build environment couldn't install or provision (no real TPM/TEE hardware, PyTorch's
CPU wheel index and huggingface.co both blocked by network egress here). Each substitution is
documented directly in that module's own docstring, and summarized in `docs/AINN_MASTER.md` under
"Honest, documented limitations." Know these before a viva — they're the first thing worth being
asked about.
